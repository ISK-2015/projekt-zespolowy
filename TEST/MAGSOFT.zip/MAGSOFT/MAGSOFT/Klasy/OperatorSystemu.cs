﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MAGSOFT.Klasy
{
    class OperatorSystemu
    {
        Pracownik _Operator;
        int PoziomUprawnien; // 10 - odczyt; 01 - zapis, 11 - odczyt i zapis;
    }
}
