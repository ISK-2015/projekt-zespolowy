﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MAGSOFT.Klasy
{
    class Kontrahent
    {
        int _NIP;
        string _NazwaFirmy;
        Adres AdresKlienta;
        Bank _BankKlienta;
        DateTime _DataRejestracji;
        int _NrTel;
    }
}
