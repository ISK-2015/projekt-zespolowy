﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGSOFT.Klasy
{
    class Bank
    {
        string _NazwaBanku;
        int _NumerKonta;
    }
}
