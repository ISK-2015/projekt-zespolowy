﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAGSOFT.Klasy
{
    class Pracownik
    {
        int _id;
        string _Imie;
        string _Nazwisko;
        string _Stanowisko;
        string _Przelozony;
        int _TelefonKontaktowy;
        DateTime _DataZatrudnienia;
    }
}
